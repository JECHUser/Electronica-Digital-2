/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef tabla_7seg
#define	tabla_7seg

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h>

void tabla(uint8_t adc_lecture);

#endif

